# HomeBank Backend API

A production-ready Node.js/Express REST API for the HomeBank personal finance app.

---

## Stack

| Layer | Technology |
|---|---|
| Runtime | Node.js 18+ |
| Framework | Express 4 |
| ORM | Prisma 5 |
| Database | SQLite (dev) · PostgreSQL (prod) |
| Auth | JWT access tokens + refresh tokens |
| Password | bcryptjs (12 rounds) |
| Validation | express-validator |
| Security | helmet · cors · rate-limit |

---

## Quick Start

### 1. Install dependencies
```bash
npm install
```

### 2. Configure environment
```bash
cp .env.example .env
# Edit .env — change JWT secrets and DATABASE_URL
```

### 3. Set up the database
```bash
# Push schema to SQLite (dev)
npx prisma db push

# Or run migrations (recommended for prod)
npx prisma migrate dev --name init
```

### 4. Seed demo data
```bash
node src/utils/seed.js
```

### 5. Start the server
```bash
npm run dev     # development (nodemon)
npm start       # production
```

The API will be live at `http://localhost:3001`

---

## Production (PostgreSQL + Cloudflare)

### Switch to PostgreSQL
In `.env`:
```
DATABASE_URL="postgresql://user:password@host:5432/homebank?sslmode=require"
```

In `prisma/schema.prisma`, change:
```prisma
datasource db {
  provider = "postgresql"   // ← change from "sqlite"
  url      = env("DATABASE_URL")
}
```

Then run:
```bash
npx prisma migrate deploy
```

### Deploy on a VPS / Railway / Render
1. Set all env vars on your host
2. Run `npx prisma migrate deploy` on deploy
3. `npm start`

### Cloudflare (Pages + Workers)
The frontend `index.html` deploys as a **Cloudflare Page**.  
The Node.js backend runs on a **VPS** (Railway, Render, Fly.io, etc.) or as a **Cloudflare Worker** (requires porting from Express to the Fetch API).

Point the frontend API base URL to your deployed backend:
```js
// In index.html, replace the API_BASE constant:
const API_BASE = 'https://api.yourdomain.com';
```

---

## API Reference

All protected routes require:
```
Authorization: Bearer <accessToken>
```

### Auth
| Method | Path | Auth | Description |
|---|---|---|---|
| POST | `/api/auth/register` | No | Create account |
| POST | `/api/auth/login` | No | Sign in |
| POST | `/api/auth/refresh` | No | Rotate tokens |
| POST | `/api/auth/logout` | Yes | Revoke refresh token |
| GET | `/api/auth/me` | Yes | Get current user |
| PUT | `/api/auth/me` | Yes | Update name/greeting |
| PUT | `/api/auth/password` | Yes | Change password |

### Dashboard (all require auth)
| Method | Path | Description |
|---|---|---|
| GET | `/api/dashboard` | Full dashboard payload (kpi + accounts + budgets + txns + cashflow) |
| GET | `/api/dashboard/kpi` | KPI cards only |
| PUT | `/api/dashboard/kpi` | Update KPI values |
| GET | `/api/dashboard/cashflow` | Cash flow chart data |
| POST | `/api/dashboard/cashflow` | Add a cash flow entry |

### Accounts
| Method | Path | Description |
|---|---|---|
| GET | `/api/accounts` | List all accounts |
| POST | `/api/accounts` | Create account |
| PUT | `/api/accounts/:id` | Update account |
| DELETE | `/api/accounts/:id` | Delete account |

### Transactions
| Method | Path | Description |
|---|---|---|
| GET | `/api/transactions` | List (supports `?cat=&search=&limit=&offset=&sort=`) |
| GET | `/api/transactions/summary` | Spending totals by category |
| POST | `/api/transactions` | Add transaction |
| PUT | `/api/transactions/:id` | Edit transaction |
| DELETE | `/api/transactions/:id` | Delete transaction |

### Budgets
| Method | Path | Description |
|---|---|---|
| GET | `/api/budgets` | List budgets |
| POST | `/api/budgets` | Create budget |
| PUT | `/api/budgets/:id` | Update budget |
| DELETE | `/api/budgets/:id` | Delete budget |

### Admin (requires ADMIN role)
| Method | Path | Description |
|---|---|---|
| GET | `/api/admin/stats` | Platform stats |
| GET | `/api/admin/users` | List all users |
| GET | `/api/admin/users/:id` | Full user data |
| POST | `/api/admin/users` | Create user |
| PUT | `/api/admin/users/:id` | Update user |
| DELETE | `/api/admin/users/:id` | Delete user |
| PUT | `/api/admin/users/:id/kpi` | Update user's KPI data |

---

## Example Requests

### Register
```bash
curl -X POST http://localhost:3001/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"name":"Alex Müller","email":"alex@example.com","password":"Secure123!"}'
```

### Login
```bash
curl -X POST http://localhost:3001/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"alex@example.com","password":"Secure123!"}'
```

### Get dashboard
```bash
curl http://localhost:3001/api/dashboard \
  -H "Authorization: Bearer <accessToken>"
```

### Add a transaction
```bash
curl -X POST http://localhost:3001/api/transactions \
  -H "Authorization: Bearer <accessToken>" \
  -H "Content-Type: application/json" \
  -d '{"name":"Lidl","cat":"Groceries","amt":-32.50,"date":"Today","icon":"🛒"}'
```

---

## Connecting the Frontend

In `index.html`, add this near the top of the `<script>` block:

```js
const API_BASE = 'http://localhost:3001'; // change to your deployed URL

async function api(path, options = {}) {
  const token = localStorage.getItem('hb_token');
  const res = await fetch(API_BASE + path, {
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: 'Bearer ' + token } : {}),
    },
    ...options,
  });
  return res.json();
}
```

Then replace the in-memory `handleSignIn()` / `handleSignUp()` with real API calls:

```js
async function handleSignIn() {
  const email = document.getElementById('signinEmail').value;
  const password = document.getElementById('signinPassword').value;
  const data = await api('/api/auth/login', {
    method: 'POST',
    body: JSON.stringify({ email, password }),
  });
  if (data.ok) {
    localStorage.setItem('hb_token', data.data.accessToken);
    localStorage.setItem('hb_refresh', data.data.refreshToken);
    currentUser = data.data.user;
    showView('dashboard');
  } else {
    showToast('error', 'Login failed', data.message);
  }
}
```

---

## Security Notes

- **Change all JWT secrets** in `.env` before deploying
- Enable `NODE_ENV=production` in prod
- Set `CORS_ORIGIN` to your exact frontend domain
- Use HTTPS in production (Cloudflare handles this automatically)
- Refresh tokens are rotated on every use
- Passwords are hashed with bcrypt (12 rounds)
- Rate limiting: 10 auth attempts / 15 min per IP

---

## Default Credentials (after seed)

| Role | Email | Password |
|---|---|---|
| Admin | admin@homebank.app | Admin123! |
| Demo | alex@example.com | Demo1234! |

**Change these in production.**

---

## Project Structure

```
homebank-backend/
├── prisma/
│   └── schema.prisma          # Database models
├── src/
│   ├── index.js               # Express app & server
│   ├── middleware/
│   │   ├── auth.js            # JWT auth + admin guard
│   │   └── validate.js        # express-validator helper
│   ├── routes/
│   │   ├── auth.js            # Register, login, refresh, me
│   │   ├── accounts.js        # Bank account CRUD
│   │   ├── transactions.js    # Transaction CRUD + summary
│   │   ├── budgets.js         # Budget CRUD
│   │   ├── dashboard.js       # KPI + cashflow
│   │   └── admin.js           # Admin user management
│   └── utils/
│       ├── jwt.js             # Token sign/verify helpers
│       ├── prisma.js          # Prisma client singleton
│       ├── response.js        # Consistent JSON response helpers
│       └── seed.js            # Database seed script
├── .env.example               # Environment template
└── package.json
```
