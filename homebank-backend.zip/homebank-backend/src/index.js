require('dotenv').config();
const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const morgan = require('morgan');
const rateLimit = require('express-rate-limit');

const { sendError } = require('./utils/response');

// ─── Routes ──────────────────────────────────────────────────
const authRoutes = require('./routes/auth');
const accountRoutes = require('./routes/accounts');
const transactionRoutes = require('./routes/transactions');
const budgetRoutes = require('./routes/budgets');
const dashboardRoutes = require('./routes/dashboard');
const adminRoutes = require('./routes/admin');

const app = express();
const PORT = process.env.PORT || 3001;

// ─── Security Middleware ──────────────────────────────────────
app.use(helmet());

app.use(cors({
  origin: process.env.CORS_ORIGIN || '*',
  methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization'],
  credentials: true,
}));

// ─── General Rate Limiter ─────────────────────────────────────
const generalLimiter = rateLimit({
  windowMs: parseInt(process.env.RATE_LIMIT_WINDOW_MS) || 15 * 60 * 1000,
  max: parseInt(process.env.RATE_LIMIT_MAX) || 100,
  standardHeaders: true,
  legacyHeaders: false,
  message: { ok: false, message: 'Too many requests. Please slow down.' },
});
app.use('/api/', generalLimiter);

// ─── Body Parsing ─────────────────────────────────────────────
app.use(express.json({ limit: '1mb' }));
app.use(express.urlencoded({ extended: true }));

// ─── Logging ─────────────────────────────────────────────────
if (process.env.NODE_ENV !== 'test') {
  app.use(morgan(process.env.NODE_ENV === 'production' ? 'combined' : 'dev'));
}

// ─── Health Check ─────────────────────────────────────────────
app.get('/health', (req, res) => {
  res.json({ ok: true, service: 'homebank-api', timestamp: new Date().toISOString() });
});

// ─── API Routes ───────────────────────────────────────────────
app.use('/api/auth', authRoutes);
app.use('/api/accounts', accountRoutes);
app.use('/api/transactions', transactionRoutes);
app.use('/api/budgets', budgetRoutes);
app.use('/api/dashboard', dashboardRoutes);
app.use('/api/admin', adminRoutes);

// ─── API Docs (quick reference) ───────────────────────────────
app.get('/api', (req, res) => {
  res.json({
    ok: true,
    name: 'HomeBank API',
    version: '1.0.0',
    endpoints: {
      health: 'GET /health',
      auth: {
        register: 'POST /api/auth/register',
        login: 'POST /api/auth/login',
        refresh: 'POST /api/auth/refresh',
        logout: 'POST /api/auth/logout',
        me: 'GET /api/auth/me',
        updateMe: 'PUT /api/auth/me',
        changePassword: 'PUT /api/auth/password',
      },
      dashboard: {
        full: 'GET /api/dashboard',
        kpi: 'GET /api/dashboard/kpi',
        updateKpi: 'PUT /api/dashboard/kpi',
        cashflow: 'GET /api/dashboard/cashflow',
        addCashflow: 'POST /api/dashboard/cashflow',
      },
      accounts: {
        list: 'GET /api/accounts',
        create: 'POST /api/accounts',
        update: 'PUT /api/accounts/:id',
        delete: 'DELETE /api/accounts/:id',
      },
      transactions: {
        list: 'GET /api/transactions?cat=&search=&limit=20&offset=0',
        summary: 'GET /api/transactions/summary',
        create: 'POST /api/transactions',
        update: 'PUT /api/transactions/:id',
        delete: 'DELETE /api/transactions/:id',
      },
      budgets: {
        list: 'GET /api/budgets',
        create: 'POST /api/budgets',
        update: 'PUT /api/budgets/:id',
        delete: 'DELETE /api/budgets/:id',
      },
      admin: {
        stats: 'GET /api/admin/stats',
        listUsers: 'GET /api/admin/users',
        getUser: 'GET /api/admin/users/:id',
        createUser: 'POST /api/admin/users',
        updateUser: 'PUT /api/admin/users/:id',
        deleteUser: 'DELETE /api/admin/users/:id',
        updateUserKpi: 'PUT /api/admin/users/:id/kpi',
      },
    },
  });
});

// ─── 404 Handler ─────────────────────────────────────────────
app.use((req, res) => {
  sendError(res, `Route ${req.method} ${req.path} not found`, 404);
});

// ─── Global Error Handler ─────────────────────────────────────
app.use((err, req, res, next) => {
  console.error('[unhandled error]', err);
  sendError(res, 'Internal server error', 500);
});

// ─── Start Server ─────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`
╔════════════════════════════════════════╗
║        HomeBank API Server             ║
╠════════════════════════════════════════╣
║  Status:  Running                      ║
║  Port:    ${PORT}                          ║
║  Env:     ${(process.env.NODE_ENV || 'development').padEnd(26)}║
║  Docs:    http://localhost:${PORT}/api     ║
║  Health:  http://localhost:${PORT}/health  ║
╚════════════════════════════════════════╝
  `);
});

module.exports = app;
