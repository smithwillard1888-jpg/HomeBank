// HomeBank — Database Seed
// Run: node src/utils/seed.js
require('dotenv').config();
const bcrypt = require('bcryptjs');
const prisma = require('./prisma');

async function main() {
  console.log('🌱 Seeding HomeBank database...\n');

  // ─── Admin user ──────────────────────────────────────────
  const adminPassword = await bcrypt.hash(process.env.ADMIN_PASSWORD || 'Admin123!', 12);
  const admin = await prisma.user.upsert({
    where: { email: process.env.ADMIN_EMAIL || 'admin@homebank.app' },
    update: {},
    create: {
      name: 'Admin User',
      email: process.env.ADMIN_EMAIL || 'admin@homebank.app',
      passwordHash: adminPassword,
      avatar: 'AU',
      role: 'ADMIN',
      plan: 'PREMIUM',
      status: 'offline',
      greeting: 'Hello, Admin',
      kpi: { create: { netWorth: 0, spent: 0, saved: 0, subs: 0 } },
    },
  });
  console.log(`✅ Admin: ${admin.email}`);

  // ─── Demo user ───────────────────────────────────────────
  const demoPassword = await bcrypt.hash('Demo1234!', 12);
  const demo = await prisma.user.upsert({
    where: { email: 'alex@example.com' },
    update: {},
    create: {
      name: 'Alex Müller',
      email: 'alex@example.com',
      passwordHash: demoPassword,
      avatar: 'AM',
      role: 'USER',
      plan: 'PREMIUM',
      status: 'offline',
      greeting: 'Good morning, Alex',
      kpi: {
        create: {
          netWorth: 28450,
          netWorthDelta: '+€1,240 this month',
          netWorthDeltaUp: true,
          spent: 1832,
          spentDelta: '+8% vs last month',
          spentDeltaUp: false,
          saved: 620,
          savedDelta: '+€120 vs May',
          savedDeltaUp: true,
          subs: 84,
          subsLabel: '8 active services',
        },
      },
      accounts: {
        create: [
          { name: 'DKB Checking', type: 'Bank account', bal: 4820, color: '#4f8ef7', order: 0 },
          { name: 'N26 Savings', type: 'Savings account', bal: 18300, color: '#22c87a', order: 1 },
          { name: 'Barclays Credit', type: 'Credit card', bal: -670, color: '#f75f5f', order: 2 },
          { name: 'PayPal', type: 'Digital wallet', bal: 234, color: '#a78bfa', order: 3 },
          { name: 'Cash', type: 'Cash', bal: 95, color: '#f5a623', order: 4 },
          { name: 'ETF Portfolio', type: 'Investment', bal: 5671, color: '#4f8ef7', order: 5 },
        ],
      },
      budgets: {
        create: [
          { name: 'Housing', spent: 780, total: 800, color: '#4f8ef7', order: 0 },
          { name: 'Food & Groceries', spent: 320, total: 400, color: '#22c87a', order: 1 },
          { name: 'Transport', spent: 186, total: 200, color: '#a78bfa', order: 2 },
          { name: 'Health', spent: 95, total: 150, color: '#f75f5f', order: 3 },
          { name: 'Entertainment', spent: 140, total: 150, color: '#f5a623', order: 4 },
          { name: 'Subscriptions', spent: 84, total: 100, color: '#22c87a', order: 5 },
          { name: 'Clothing', spent: 227, total: 200, color: '#f75f5f', order: 6 },
        ],
      },
      transactions: {
        create: [
          { icon: '🛒', name: 'Rewe', cat: 'Groceries', date: 'Today', amt: -54.20, bg: 'rgba(79,142,247,.13)' },
          { icon: '☕', name: 'Coffee Collective', cat: 'Dining out', date: 'Today', amt: -4.80, bg: 'rgba(245,166,35,.13)' },
          { icon: '💰', name: 'Salary', cat: 'Income', date: '27 Jun', amt: 3200, bg: 'rgba(34,200,122,.12)' },
          { icon: '🎵', name: 'Spotify', cat: 'Subscriptions', date: '26 Jun', amt: -9.99, bg: 'rgba(167,139,250,.12)' },
          { icon: '🚇', name: 'BVG Monthly Pass', cat: 'Transport', date: '25 Jun', amt: -86, bg: 'rgba(79,142,247,.13)' },
          { icon: '💊', name: 'Pharmacy', cat: 'Health', date: '24 Jun', amt: -18.50, bg: 'rgba(34,200,122,.12)' },
          { icon: '🍕', name: "Domino's", cat: 'Dining out', date: '23 Jun', amt: -22.40, bg: 'rgba(245,166,35,.13)' },
          { icon: '📺', name: 'Netflix', cat: 'Subscriptions', date: '22 Jun', amt: -15.99, bg: 'rgba(167,139,250,.12)' },
        ],
      },
      cashFlows: {
        create: [
          { month: 'Jan', income: 3200, spending: 1960, year: 2026, order: 0 },
          { month: 'Feb', income: 3200, spending: 2100, year: 2026, order: 1 },
          { month: 'Mar', income: 3450, spending: 1780, year: 2026, order: 2 },
          { month: 'Apr', income: 3200, spending: 2340, year: 2026, order: 3 },
          { month: 'May', income: 3200, spending: 1690, year: 2026, order: 4 },
          { month: 'Jun', income: 3200, spending: 1832, year: 2026, order: 5 },
        ],
      },
    },
  });
  console.log(`✅ Demo user: ${demo.email} / Demo1234!`);

  console.log('\n✨ Seed complete!');
  console.log('─────────────────────────────────────');
  console.log(`Admin login:  ${admin.email} / ${process.env.ADMIN_PASSWORD || 'Admin123!'}`);
  console.log(`Demo login:   alex@example.com / Demo1234!`);
  console.log('─────────────────────────────────────');
}

main()
  .catch(e => { console.error('Seed failed:', e); process.exit(1); })
  .finally(() => prisma.$disconnect());
