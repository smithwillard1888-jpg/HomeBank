function sendSuccess(res, data = {}, message = 'Success', statusCode = 200) {
  return res.status(statusCode).json({ ok: true, message, data });
}

function sendError(res, message = 'An error occurred', statusCode = 500, errors = null) {
  const body = { ok: false, message };
  if (errors) body.errors = errors;
  return res.status(statusCode).json(body);
}

function sendCreated(res, data = {}, message = 'Created') {
  return sendSuccess(res, data, message, 201);
}

module.exports = { sendSuccess, sendError, sendCreated };
