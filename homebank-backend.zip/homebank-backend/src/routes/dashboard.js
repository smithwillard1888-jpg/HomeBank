const express = require('express');
const { body } = require('express-validator');
const router = express.Router();

const prisma = require('../utils/prisma');
const { sendSuccess, sendError } = require('../utils/response');
const { authenticate } = require('../middleware/auth');
const { validate } = require('../middleware/validate');

router.use(authenticate);

// ── GET /api/dashboard ────────────────────────────────────────
// Returns full dashboard payload in one call
router.get('/', async (req, res) => {
  try {
    const userId = req.user.id;

    const [kpi, accounts, budgets, transactions, cashFlows] = await Promise.all([
      prisma.kpi.findUnique({ where: { userId } }),
      prisma.account.findMany({ where: { userId }, orderBy: { order: 'asc' } }),
      prisma.budget.findMany({ where: { userId }, orderBy: { order: 'asc' } }),
      prisma.transaction.findMany({ where: { userId }, orderBy: { createdAt: 'desc' }, take: 10 }),
      prisma.cashFlow.findMany({ where: { userId }, orderBy: { order: 'asc' } }),
    ]);

    return sendSuccess(res, { kpi, accounts, budgets, transactions, cashFlows });
  } catch (err) {
    console.error('[dashboard]', err);
    return sendError(res, 'Failed to load dashboard', 500);
  }
});

// ── GET /api/dashboard/kpi ────────────────────────────────────
router.get('/kpi', async (req, res) => {
  try {
    const kpi = await prisma.kpi.findUnique({ where: { userId: req.user.id } });
    if (!kpi) return sendError(res, 'KPI data not found', 404);
    return sendSuccess(res, { kpi });
  } catch (err) {
    return sendError(res, 'Failed to fetch KPIs', 500);
  }
});

// ── PUT /api/dashboard/kpi ────────────────────────────────────
router.put(
  '/kpi',
  [
    body('netWorth').optional().isFloat(),
    body('netWorthDelta').optional().trim().isLength({ max: 80 }),
    body('netWorthDeltaUp').optional().isBoolean(),
    body('spent').optional().isFloat({ min: 0 }),
    body('spentDelta').optional().trim().isLength({ max: 80 }),
    body('spentDeltaUp').optional().isBoolean(),
    body('saved').optional().isFloat({ min: 0 }),
    body('savedDelta').optional().trim().isLength({ max: 80 }),
    body('savedDeltaUp').optional().isBoolean(),
    body('subs').optional().isFloat({ min: 0 }),
    body('subsLabel').optional().trim().isLength({ max: 80 }),
  ],
  validate,
  async (req, res) => {
    try {
      const fields = [
        'netWorth','netWorthDelta','netWorthDeltaUp',
        'spent','spentDelta','spentDeltaUp',
        'saved','savedDelta','savedDeltaUp',
        'subs','subsLabel',
      ];
      const data = {};
      fields.forEach(f => {
        if (req.body[f] !== undefined) data[f] = req.body[f];
      });

      const kpi = await prisma.kpi.update({ where: { userId: req.user.id }, data });
      return sendSuccess(res, { kpi }, 'KPIs updated');
    } catch (err) {
      return sendError(res, 'Failed to update KPIs', 500);
    }
  }
);

// ── GET /api/dashboard/cashflow ───────────────────────────────
router.get('/cashflow', async (req, res) => {
  try {
    const cashFlows = await prisma.cashFlow.findMany({
      where: { userId: req.user.id },
      orderBy: { order: 'asc' },
    });
    return sendSuccess(res, { cashFlows });
  } catch (err) {
    return sendError(res, 'Failed to fetch cash flow', 500);
  }
});

// ── POST /api/dashboard/cashflow ──────────────────────────────
router.post(
  '/cashflow',
  [
    body('month').trim().notEmpty().isLength({ max: 10 }),
    body('income').isFloat({ min: 0 }),
    body('spending').isFloat({ min: 0 }),
    body('year').optional().isInt({ min: 2000, max: 2100 }),
  ],
  validate,
  async (req, res) => {
    try {
      const { month, income, spending, year = new Date().getFullYear() } = req.body;
      const count = await prisma.cashFlow.count({ where: { userId: req.user.id } });

      const cf = await prisma.cashFlow.create({
        data: { month, income: parseFloat(income), spending: parseFloat(spending), year, userId: req.user.id, order: count },
      });
      return sendSuccess(res, { cashFlow: cf }, 'Cash flow entry added');
    } catch (err) {
      return sendError(res, 'Failed to add cash flow', 500);
    }
  }
);

module.exports = router;
