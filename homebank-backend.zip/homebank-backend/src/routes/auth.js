const express = require('express');
const bcrypt = require('bcryptjs');
const { body } = require('express-validator');
const router = express.Router();
const rateLimit = require('express-rate-limit');

const prisma = require('../utils/prisma');
const { signAccessToken, signRefreshToken, verifyRefreshToken, getRefreshExpiryDate } = require('../utils/jwt');
const { sendSuccess, sendError, sendCreated } = require('../utils/response');
const { validate } = require('../middleware/validate');
const { authenticate } = require('../middleware/auth');

const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: parseInt(process.env.AUTH_RATE_LIMIT_MAX) || 10,
  message: { ok: false, message: 'Too many auth attempts. Try again later.' },
  standardHeaders: true,
  legacyHeaders: false,
});

// ── POST /api/auth/register ──────────────────────────────────
router.post(
  '/register',
  authLimiter,
  [
    body('name').trim().notEmpty().withMessage('Name is required').isLength({ max: 100 }),
    body('email').isEmail().normalizeEmail().withMessage('Valid email required'),
    body('password')
      .isLength({ min: 8 })
      .withMessage('Password must be at least 8 characters'),
  ],
  validate,
  async (req, res) => {
    try {
      const { name, email, password } = req.body;

      const existing = await prisma.user.findUnique({ where: { email } });
      if (existing) return sendError(res, 'Email already registered', 409);

      const passwordHash = await bcrypt.hash(password, 12);
      const initials = name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);

      const user = await prisma.user.create({
        data: {
          name,
          email,
          passwordHash,
          avatar: initials,
          greeting: `Hello, ${name.split(' ')[0]}`,
          kpi: {
            create: {}
          }
        },
        select: { id: true, name: true, email: true, role: true, plan: true, avatar: true, createdAt: true },
      });

      const tokens = await _issueTokens(user.id);

      return sendCreated(res, { user, ...tokens }, 'Account created successfully');
    } catch (err) {
      console.error('[register]', err);
      return sendError(res, 'Registration failed', 500);
    }
  }
);

// ── POST /api/auth/login ─────────────────────────────────────
router.post(
  '/login',
  authLimiter,
  [
    body('email').isEmail().normalizeEmail().withMessage('Valid email required'),
    body('password').notEmpty().withMessage('Password required'),
  ],
  validate,
  async (req, res) => {
    try {
      const { email, password } = req.body;

      const user = await prisma.user.findUnique({ where: { email } });
      if (!user) return sendError(res, 'Invalid email or password', 401);

      const valid = await bcrypt.compare(password, user.passwordHash);
      if (!valid) return sendError(res, 'Invalid email or password', 401);

      // Mark online
      await prisma.user.update({ where: { id: user.id }, data: { status: 'online' } });

      const tokens = await _issueTokens(user.id);
      const { passwordHash: _, ...safeUser } = user;

      return sendSuccess(res, { user: safeUser, ...tokens }, 'Logged in successfully');
    } catch (err) {
      console.error('[login]', err);
      return sendError(res, 'Login failed', 500);
    }
  }
);

// ── POST /api/auth/refresh ───────────────────────────────────
router.post('/refresh', async (req, res) => {
  try {
    const { refreshToken } = req.body;
    if (!refreshToken) return sendError(res, 'Refresh token required', 400);

    let payload;
    try {
      payload = verifyRefreshToken(refreshToken);
    } catch {
      return sendError(res, 'Invalid or expired refresh token', 401);
    }

    const stored = await prisma.refreshToken.findUnique({ where: { token: refreshToken } });
    if (!stored || stored.expiresAt < new Date()) {
      return sendError(res, 'Refresh token revoked or expired', 401);
    }

    // Rotate refresh token
    await prisma.refreshToken.delete({ where: { token: refreshToken } });
    const tokens = await _issueTokens(payload.sub);

    return sendSuccess(res, tokens, 'Tokens refreshed');
  } catch (err) {
    console.error('[refresh]', err);
    return sendError(res, 'Token refresh failed', 500);
  }
});

// ── POST /api/auth/logout ────────────────────────────────────
router.post('/logout', authenticate, async (req, res) => {
  try {
    const { refreshToken } = req.body;
    if (refreshToken) {
      await prisma.refreshToken.deleteMany({ where: { token: refreshToken } });
    }
    // Mark offline
    await prisma.user.update({ where: { id: req.user.id }, data: { status: 'offline' } });
    return sendSuccess(res, {}, 'Logged out successfully');
  } catch (err) {
    console.error('[logout]', err);
    return sendError(res, 'Logout failed', 500);
  }
});

// ── GET /api/auth/me ─────────────────────────────────────────
router.get('/me', authenticate, async (req, res) => {
  try {
    const user = await prisma.user.findUnique({
      where: { id: req.user.id },
      select: {
        id: true, name: true, email: true, avatar: true,
        role: true, plan: true, status: true, greeting: true,
        createdAt: true, updatedAt: true,
      },
    });
    return sendSuccess(res, { user });
  } catch (err) {
    return sendError(res, 'Could not fetch user', 500);
  }
});

// ── PUT /api/auth/me ─────────────────────────────────────────
router.put(
  '/me',
  authenticate,
  [
    body('name').optional().trim().notEmpty().isLength({ max: 100 }),
    body('greeting').optional().trim().isLength({ max: 100 }),
  ],
  validate,
  async (req, res) => {
    try {
      const { name, greeting } = req.body;
      const data = {};
      if (name) data.name = name;
      if (greeting !== undefined) data.greeting = greeting;

      const user = await prisma.user.update({
        where: { id: req.user.id },
        data,
        select: { id: true, name: true, email: true, avatar: true, role: true, plan: true, greeting: true },
      });
      return sendSuccess(res, { user }, 'Profile updated');
    } catch (err) {
      return sendError(res, 'Update failed', 500);
    }
  }
);

// ── PUT /api/auth/password ───────────────────────────────────
router.put(
  '/password',
  authenticate,
  authLimiter,
  [
    body('currentPassword').notEmpty().withMessage('Current password required'),
    body('newPassword').isLength({ min: 8 }).withMessage('New password must be at least 8 characters'),
  ],
  validate,
  async (req, res) => {
    try {
      const { currentPassword, newPassword } = req.body;
      const user = await prisma.user.findUnique({ where: { id: req.user.id } });

      const valid = await bcrypt.compare(currentPassword, user.passwordHash);
      if (!valid) return sendError(res, 'Current password is incorrect', 401);

      const passwordHash = await bcrypt.hash(newPassword, 12);
      await prisma.user.update({ where: { id: req.user.id }, data: { passwordHash } });
      // Revoke all refresh tokens on password change
      await prisma.refreshToken.deleteMany({ where: { userId: req.user.id } });

      return sendSuccess(res, {}, 'Password updated. Please log in again.');
    } catch (err) {
      return sendError(res, 'Password update failed', 500);
    }
  }
);

// ── Helper ────────────────────────────────────────────────────
async function _issueTokens(userId) {
  const accessToken = signAccessToken({ sub: userId });
  const refreshToken = signRefreshToken({ sub: userId });

  await prisma.refreshToken.create({
    data: {
      token: refreshToken,
      userId,
      expiresAt: getRefreshExpiryDate(),
    },
  });

  return { accessToken, refreshToken };
}

module.exports = router;
