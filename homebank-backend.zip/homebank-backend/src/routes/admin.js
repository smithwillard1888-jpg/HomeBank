const express = require('express');
const bcrypt = require('bcryptjs');
const { body, param, query } = require('express-validator');
const router = express.Router();

const prisma = require('../utils/prisma');
const { sendSuccess, sendError, sendCreated } = require('../utils/response');
const { authenticate, requireAdmin } = require('../middleware/auth');
const { validate } = require('../middleware/validate');

// All admin routes require auth + admin role
router.use(authenticate, requireAdmin);

// ── GET /api/admin/users ──────────────────────────────────────
router.get(
  '/users',
  [
    query('search').optional().trim(),
    query('limit').optional().isInt({ min: 1, max: 100 }),
    query('offset').optional().isInt({ min: 0 }),
  ],
  validate,
  async (req, res) => {
    try {
      const limit = parseInt(req.query.limit) || 50;
      const offset = parseInt(req.query.offset) || 0;
      const { search } = req.query;

      const where = search ? {
        OR: [
          { name: { contains: search } },
          { email: { contains: search } },
        ],
      } : {};

      const [users, total] = await Promise.all([
        prisma.user.findMany({
          where,
          orderBy: { createdAt: 'desc' },
          take: limit,
          skip: offset,
          select: {
            id: true, name: true, email: true, avatar: true,
            role: true, plan: true, status: true, greeting: true,
            createdAt: true, updatedAt: true,
            _count: { select: { accounts: true, transactions: true, budgets: true } },
          },
        }),
        prisma.user.count({ where }),
      ]);

      return sendSuccess(res, { users, total, limit, offset });
    } catch (err) {
      return sendError(res, 'Failed to fetch users', 500);
    }
  }
);

// ── GET /api/admin/users/:id ──────────────────────────────────
router.get(
  '/users/:id',
  [param('id').isUUID()],
  validate,
  async (req, res) => {
    try {
      const user = await prisma.user.findUnique({
        where: { id: req.params.id },
        select: {
          id: true, name: true, email: true, avatar: true,
          role: true, plan: true, status: true, greeting: true,
          createdAt: true,
          kpi: true,
          accounts: { orderBy: { order: 'asc' } },
          budgets: { orderBy: { order: 'asc' } },
          transactions: { orderBy: { createdAt: 'desc' }, take: 50 },
          cashFlows: { orderBy: { order: 'asc' } },
        },
      });
      if (!user) return sendError(res, 'User not found', 404);
      return sendSuccess(res, { user });
    } catch (err) {
      return sendError(res, 'Failed to fetch user', 500);
    }
  }
);

// ── POST /api/admin/users ─────────────────────────────────────
router.post(
  '/users',
  [
    body('name').trim().notEmpty().isLength({ max: 100 }),
    body('email').isEmail().normalizeEmail(),
    body('password').isLength({ min: 8 }),
    body('role').optional().isIn(['USER', 'ADMIN']),
    body('plan').optional().isIn(['FREE', 'PREMIUM']),
  ],
  validate,
  async (req, res) => {
    try {
      const { name, email, password, role = 'USER', plan = 'FREE' } = req.body;

      const existing = await prisma.user.findUnique({ where: { email } });
      if (existing) return sendError(res, 'Email already registered', 409);

      const passwordHash = await bcrypt.hash(password, 12);
      const initials = name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);

      const user = await prisma.user.create({
        data: {
          name, email, passwordHash, avatar: initials,
          greeting: `Hello, ${name.split(' ')[0]}`,
          role, plan,
          kpi: { create: {} },
        },
        select: { id: true, name: true, email: true, role: true, plan: true, createdAt: true },
      });

      return sendCreated(res, { user }, 'User created');
    } catch (err) {
      return sendError(res, 'Failed to create user', 500);
    }
  }
);

// ── PUT /api/admin/users/:id ──────────────────────────────────
router.put(
  '/users/:id',
  [
    param('id').isUUID(),
    body('name').optional().trim().notEmpty().isLength({ max: 100 }),
    body('email').optional().isEmail().normalizeEmail(),
    body('role').optional().isIn(['USER', 'ADMIN']),
    body('plan').optional().isIn(['FREE', 'PREMIUM']),
    body('status').optional().isIn(['online', 'offline']),
    body('greeting').optional().trim().isLength({ max: 100 }),
  ],
  validate,
  async (req, res) => {
    try {
      const existing = await prisma.user.findUnique({ where: { id: req.params.id } });
      if (!existing) return sendError(res, 'User not found', 404);

      const data = {};
      ['name', 'email', 'role', 'plan', 'status', 'greeting'].forEach(f => {
        if (req.body[f] !== undefined) data[f] = req.body[f];
      });

      const user = await prisma.user.update({
        where: { id: req.params.id },
        data,
        select: { id: true, name: true, email: true, role: true, plan: true, status: true },
      });
      return sendSuccess(res, { user }, 'User updated');
    } catch (err) {
      return sendError(res, 'Failed to update user', 500);
    }
  }
);

// ── DELETE /api/admin/users/:id ───────────────────────────────
router.delete(
  '/users/:id',
  [param('id').isUUID()],
  validate,
  async (req, res) => {
    try {
      if (req.params.id === req.user.id) {
        return sendError(res, 'Cannot delete your own account', 400);
      }
      const existing = await prisma.user.findUnique({ where: { id: req.params.id } });
      if (!existing) return sendError(res, 'User not found', 404);

      await prisma.user.delete({ where: { id: req.params.id } });
      return sendSuccess(res, {}, 'User deleted');
    } catch (err) {
      return sendError(res, 'Failed to delete user', 500);
    }
  }
);

// ── PUT /api/admin/users/:id/kpi ──────────────────────────────
router.put(
  '/users/:id/kpi',
  [param('id').isUUID()],
  validate,
  async (req, res) => {
    try {
      const user = await prisma.user.findUnique({ where: { id: req.params.id } });
      if (!user) return sendError(res, 'User not found', 404);

      const fields = ['netWorth','netWorthDelta','netWorthDeltaUp','spent','spentDelta','spentDeltaUp','saved','savedDelta','savedDeltaUp','subs','subsLabel'];
      const data = {};
      fields.forEach(f => { if (req.body[f] !== undefined) data[f] = req.body[f]; });

      const kpi = await prisma.kpi.upsert({
        where: { userId: req.params.id },
        update: data,
        create: { userId: req.params.id, ...data },
      });
      return sendSuccess(res, { kpi }, 'KPIs updated');
    } catch (err) {
      return sendError(res, 'Failed to update KPIs', 500);
    }
  }
);

// ── GET /api/admin/stats ──────────────────────────────────────
router.get('/stats', async (req, res) => {
  try {
    const [totalUsers, premiumUsers, totalTransactions, totalAccounts, onlineUsers] = await Promise.all([
      prisma.user.count(),
      prisma.user.count({ where: { plan: 'PREMIUM' } }),
      prisma.transaction.count(),
      prisma.account.count(),
      prisma.user.count({ where: { status: 'online' } }),
    ]);

    return sendSuccess(res, {
      totalUsers, premiumUsers, freeUsers: totalUsers - premiumUsers,
      totalTransactions, totalAccounts, onlineUsers,
    });
  } catch (err) {
    return sendError(res, 'Failed to fetch stats', 500);
  }
});

module.exports = router;
