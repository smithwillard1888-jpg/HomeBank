const express = require('express');
const { body, param, query } = require('express-validator');
const router = express.Router();

const prisma = require('../utils/prisma');
const { sendSuccess, sendError, sendCreated } = require('../utils/response');
const { authenticate } = require('../middleware/auth');
const { validate } = require('../middleware/validate');

router.use(authenticate);

// ── GET /api/transactions ─────────────────────────────────────
// Supports: ?cat=Groceries&search=rewe&limit=20&offset=0&sort=desc
router.get(
  '/',
  [
    query('limit').optional().isInt({ min: 1, max: 100 }),
    query('offset').optional().isInt({ min: 0 }),
    query('sort').optional().isIn(['asc', 'desc']),
  ],
  validate,
  async (req, res) => {
    try {
      const limit = parseInt(req.query.limit) || 20;
      const offset = parseInt(req.query.offset) || 0;
      const sort = req.query.sort || 'desc';
      const { cat, search } = req.query;

      const where = { userId: req.user.id };
      if (cat) where.cat = cat;
      if (search) where.name = { contains: search };

      const [transactions, total] = await Promise.all([
        prisma.transaction.findMany({
          where,
          orderBy: { createdAt: sort },
          take: limit,
          skip: offset,
        }),
        prisma.transaction.count({ where }),
      ]);

      return sendSuccess(res, { transactions, total, limit, offset });
    } catch (err) {
      return sendError(res, 'Failed to fetch transactions', 500);
    }
  }
);

// ── POST /api/transactions ────────────────────────────────────
router.post(
  '/',
  [
    body('name').trim().notEmpty().withMessage('Transaction name required').isLength({ max: 100 }),
    body('amt').isFloat().withMessage('Amount must be a number'),
    body('cat').optional().trim().isLength({ max: 50 }),
    body('date').optional().trim().isLength({ max: 30 }),
    body('icon').optional().trim().isLength({ max: 10 }),
    body('bg').optional().trim().isLength({ max: 60 }),
  ],
  validate,
  async (req, res) => {
    try {
      const { name, amt, cat = 'Other', date = 'Today', icon = '💸', bg = 'rgba(79,142,247,.13)' } = req.body;

      const txn = await prisma.transaction.create({
        data: { name, amt: parseFloat(amt), cat, date, icon, bg, userId: req.user.id },
      });
      return sendCreated(res, { transaction: txn }, 'Transaction added');
    } catch (err) {
      return sendError(res, 'Failed to create transaction', 500);
    }
  }
);

// ── PUT /api/transactions/:id ─────────────────────────────────
router.put(
  '/:id',
  [
    param('id').isUUID(),
    body('name').optional().trim().notEmpty().isLength({ max: 100 }),
    body('amt').optional().isFloat(),
    body('cat').optional().trim().isLength({ max: 50 }),
    body('date').optional().trim().isLength({ max: 30 }),
  ],
  validate,
  async (req, res) => {
    try {
      const txn = await prisma.transaction.findFirst({
        where: { id: req.params.id, userId: req.user.id },
      });
      if (!txn) return sendError(res, 'Transaction not found', 404);

      const data = {};
      ['name', 'cat', 'date', 'icon', 'bg'].forEach(f => {
        if (req.body[f] !== undefined) data[f] = req.body[f];
      });
      if (req.body.amt !== undefined) data.amt = parseFloat(req.body.amt);

      const updated = await prisma.transaction.update({ where: { id: req.params.id }, data });
      return sendSuccess(res, { transaction: updated }, 'Transaction updated');
    } catch (err) {
      return sendError(res, 'Failed to update transaction', 500);
    }
  }
);

// ── DELETE /api/transactions/:id ──────────────────────────────
router.delete(
  '/:id',
  [param('id').isUUID()],
  validate,
  async (req, res) => {
    try {
      const txn = await prisma.transaction.findFirst({
        where: { id: req.params.id, userId: req.user.id },
      });
      if (!txn) return sendError(res, 'Transaction not found', 404);

      await prisma.transaction.delete({ where: { id: req.params.id } });
      return sendSuccess(res, {}, 'Transaction deleted');
    } catch (err) {
      return sendError(res, 'Failed to delete transaction', 500);
    }
  }
);

// ── GET /api/transactions/summary ────────────────────────────
// Returns spending totals by category
router.get('/summary', async (req, res) => {
  try {
    const txns = await prisma.transaction.findMany({
      where: { userId: req.user.id },
      select: { cat: true, amt: true },
    });

    const byCategory = {};
    let totalIn = 0, totalOut = 0;

    for (const t of txns) {
      if (t.amt > 0) { totalIn += t.amt; continue; }
      totalOut += Math.abs(t.amt);
      byCategory[t.cat] = (byCategory[t.cat] || 0) + Math.abs(t.amt);
    }

    const categories = Object.entries(byCategory)
      .map(([cat, total]) => ({ cat, total: Math.round(total * 100) / 100 }))
      .sort((a, b) => b.total - a.total);

    return sendSuccess(res, { totalIn, totalOut, categories });
  } catch (err) {
    return sendError(res, 'Failed to compute summary', 500);
  }
});

module.exports = router;
