const express = require('express');
const { body, param } = require('express-validator');
const router = express.Router();

const prisma = require('../utils/prisma');
const { sendSuccess, sendError, sendCreated } = require('../utils/response');
const { authenticate } = require('../middleware/auth');
const { validate } = require('../middleware/validate');

// All routes require auth
router.use(authenticate);

// ── GET /api/accounts ─────────────────────────────────────────
router.get('/', async (req, res) => {
  try {
    const accounts = await prisma.account.findMany({
      where: { userId: req.user.id },
      orderBy: { order: 'asc' },
    });
    return sendSuccess(res, { accounts });
  } catch (err) {
    return sendError(res, 'Failed to fetch accounts', 500);
  }
});

// ── POST /api/accounts ────────────────────────────────────────
router.post(
  '/',
  [
    body('name').trim().notEmpty().withMessage('Account name required').isLength({ max: 100 }),
    body('type').optional().trim().isLength({ max: 50 }),
    body('bal').optional().isFloat().withMessage('Balance must be a number'),
    body('color').optional().matches(/^#[0-9a-fA-F]{6}$/).withMessage('Invalid color hex'),
  ],
  validate,
  async (req, res) => {
    try {
      const { name, type = 'Bank account', bal = 0, color = '#4f8ef7' } = req.body;

      const count = await prisma.account.count({ where: { userId: req.user.id } });
      const account = await prisma.account.create({
        data: { name, type, bal: parseFloat(bal), color, userId: req.user.id, order: count },
      });
      return sendCreated(res, { account }, 'Account created');
    } catch (err) {
      return sendError(res, 'Failed to create account', 500);
    }
  }
);

// ── PUT /api/accounts/:id ─────────────────────────────────────
router.put(
  '/:id',
  [
    param('id').isUUID().withMessage('Invalid account ID'),
    body('name').optional().trim().notEmpty().isLength({ max: 100 }),
    body('type').optional().trim().isLength({ max: 50 }),
    body('bal').optional().isFloat(),
    body('color').optional().matches(/^#[0-9a-fA-F]{6}$/),
  ],
  validate,
  async (req, res) => {
    try {
      const account = await prisma.account.findFirst({
        where: { id: req.params.id, userId: req.user.id },
      });
      if (!account) return sendError(res, 'Account not found', 404);

      const data = {};
      if (req.body.name !== undefined) data.name = req.body.name;
      if (req.body.type !== undefined) data.type = req.body.type;
      if (req.body.bal !== undefined) data.bal = parseFloat(req.body.bal);
      if (req.body.color !== undefined) data.color = req.body.color;

      const updated = await prisma.account.update({ where: { id: req.params.id }, data });
      return sendSuccess(res, { account: updated }, 'Account updated');
    } catch (err) {
      return sendError(res, 'Failed to update account', 500);
    }
  }
);

// ── DELETE /api/accounts/:id ──────────────────────────────────
router.delete(
  '/:id',
  [param('id').isUUID()],
  validate,
  async (req, res) => {
    try {
      const account = await prisma.account.findFirst({
        where: { id: req.params.id, userId: req.user.id },
      });
      if (!account) return sendError(res, 'Account not found', 404);

      await prisma.account.delete({ where: { id: req.params.id } });
      return sendSuccess(res, {}, 'Account deleted');
    } catch (err) {
      return sendError(res, 'Failed to delete account', 500);
    }
  }
);

module.exports = router;
