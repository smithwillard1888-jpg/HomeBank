const express = require('express');
const { body, param } = require('express-validator');
const router = express.Router();

const prisma = require('../utils/prisma');
const { sendSuccess, sendError, sendCreated } = require('../utils/response');
const { authenticate } = require('../middleware/auth');
const { validate } = require('../middleware/validate');

router.use(authenticate);

// ── GET /api/budgets ──────────────────────────────────────────
router.get('/', async (req, res) => {
  try {
    const budgets = await prisma.budget.findMany({
      where: { userId: req.user.id },
      orderBy: { order: 'asc' },
    });
    return sendSuccess(res, { budgets });
  } catch (err) {
    return sendError(res, 'Failed to fetch budgets', 500);
  }
});

// ── POST /api/budgets ─────────────────────────────────────────
router.post(
  '/',
  [
    body('name').trim().notEmpty().withMessage('Budget name required').isLength({ max: 100 }),
    body('total').isFloat({ min: 0 }).withMessage('Total must be a positive number'),
    body('spent').optional().isFloat({ min: 0 }),
    body('color').optional().matches(/^#[0-9a-fA-F]{6}$/),
  ],
  validate,
  async (req, res) => {
    try {
      const { name, total, spent = 0, color = '#4f8ef7' } = req.body;
      const count = await prisma.budget.count({ where: { userId: req.user.id } });

      const budget = await prisma.budget.create({
        data: { name, total: parseFloat(total), spent: parseFloat(spent), color, userId: req.user.id, order: count },
      });
      return sendCreated(res, { budget }, 'Budget created');
    } catch (err) {
      return sendError(res, 'Failed to create budget', 500);
    }
  }
);

// ── PUT /api/budgets/:id ──────────────────────────────────────
router.put(
  '/:id',
  [
    param('id').isUUID(),
    body('name').optional().trim().notEmpty().isLength({ max: 100 }),
    body('total').optional().isFloat({ min: 0 }),
    body('spent').optional().isFloat({ min: 0 }),
    body('color').optional().matches(/^#[0-9a-fA-F]{6}$/),
  ],
  validate,
  async (req, res) => {
    try {
      const budget = await prisma.budget.findFirst({
        where: { id: req.params.id, userId: req.user.id },
      });
      if (!budget) return sendError(res, 'Budget not found', 404);

      const data = {};
      if (req.body.name !== undefined) data.name = req.body.name;
      if (req.body.total !== undefined) data.total = parseFloat(req.body.total);
      if (req.body.spent !== undefined) data.spent = parseFloat(req.body.spent);
      if (req.body.color !== undefined) data.color = req.body.color;

      const updated = await prisma.budget.update({ where: { id: req.params.id }, data });
      return sendSuccess(res, { budget: updated }, 'Budget updated');
    } catch (err) {
      return sendError(res, 'Failed to update budget', 500);
    }
  }
);

// ── DELETE /api/budgets/:id ───────────────────────────────────
router.delete(
  '/:id',
  [param('id').isUUID()],
  validate,
  async (req, res) => {
    try {
      const budget = await prisma.budget.findFirst({
        where: { id: req.params.id, userId: req.user.id },
      });
      if (!budget) return sendError(res, 'Budget not found', 404);

      await prisma.budget.delete({ where: { id: req.params.id } });
      return sendSuccess(res, {}, 'Budget deleted');
    } catch (err) {
      return sendError(res, 'Failed to delete budget', 500);
    }
  }
);

module.exports = router;
